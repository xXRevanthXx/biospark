# BioSpark AI — Deployment Guide

## Folder Structure
```
biospark/
├── api/
│   └── generate.js      ← Serverless function (your API key lives here, safely)
├── public/
│   └── index.html       ← Your frontend app
├── vercel.json          ← Vercel config
└── README.md
```

---

## Step-by-Step: Deploy to Vercel (FREE)

### Step 1 — Create a GitHub Account
Go to https://github.com and sign up (free).

### Step 2 — Create a New Repository
1. Click the green **New** button
2. Name it: `biospark`
3. Set to **Public**
4. Click **Create repository**

### Step 3 — Upload Your Files
1. Click **uploading an existing file**
2. Upload these files maintaining the folder structure:
   - `api/generate.js`
   - `public/index.html`
   - `vercel.json`
3. Click **Commit changes**

### Step 4 — Create a Vercel Account
Go to https://vercel.com and sign up with your GitHub account (free).

### Step 5 — Deploy on Vercel
1. Click **Add New Project**
2. Select your `biospark` GitHub repo
3. Click **Deploy** (leave all settings as default)
4. Wait ~1 minute — your site is live! 🎉

### Step 6 — Add Your Claude API Key (IMPORTANT)
This is how your key stays safe and hidden:
1. In Vercel dashboard, go to your project
2. Click **Settings** → **Environment Variables**
3. Click **Add New**
   - Name: `CLAUDE_API_KEY`
   - Value: `sk-ant-api03-...` (your actual key)
4. Click **Save**
5. Go to **Deployments** → click **Redeploy** (so it picks up the new key)

Your site URL will be something like: `https://biospark.vercel.app`

---

## How to Add Google AdSense (Earn from Ads)

### Step 1 — Apply for AdSense
1. Go to https://adsense.google.com
2. Sign up with your Google account
3. Enter your website URL (your Vercel URL)
4. Fill in your payment details (bank/UPI)
5. Wait 1–2 weeks for approval (they check your site has real content)

### Step 2 — Add AdSense Code to Your Site
Once approved, Google gives you a script tag. In `public/index.html`:

Find this comment near the top:
```html
<!-- ░░ REPLACE THIS WITH YOUR GOOGLE ADSENSE SCRIPT TAG ░░ -->
```

Replace it with your AdSense script:
```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-YOUR_ID" crossorigin="anonymous"></script>
```

For ad units, replace the `.ad-top-inner` div and `.ad-box` divs with your AdSense `<ins>` tags.

---

## Rate Limiting (Protect Your ₹180 API Budget)

Currently set to **3 free generations per user per day**.
To change this, edit `api/generate.js`:
```js
const RATE_LIMIT = 3; // ← change this number
```

### Budget Math (Claude Haiku model):
- Each generation ≈ 500 tokens input + 400 tokens output
- Cost per generation ≈ ₹0.04 (very cheap!)
- ₹180 budget = ~4,500 generations
- 100 users/day × 3 uses = 300 generations/day
- ₹180 lasts ~15 days at 100 users/day

**Tip**: Add more money to your Claude account as your traffic grows. AdSense earnings will cover it.

---

## Upgrading Rate Limit Storage (Optional, Later)

The current rate limiter uses in-memory storage (resets on each deploy).
For production, upgrade to **Vercel KV** (free tier available):
- Go to Vercel Dashboard → Storage → Create KV Database
- I can write the upgraded code when you're ready

---

## Quick Checklist Before Launch
- [ ] Files uploaded to GitHub
- [ ] Deployed on Vercel
- [ ] CLAUDE_API_KEY added to environment variables
- [ ] Redeployed after adding key
- [ ] Test all 3 tools work
- [ ] Apply for Google AdSense
- [ ] Share link in Facebook groups, WhatsApp, Reddit

---

## Sharing for Traffic (Free Marketing)
Post in these places:
- Reddit: r/SideProject, r/Entrepreneur, r/Instagram
- Facebook: Creator groups, LinkedIn groups
- Product Hunt: https://producthunt.com (big launch boost!)
- IndieHackers: https://indiehackers.com
- Twitter/X with hashtag #buildinpublic

Good luck! 🚀
